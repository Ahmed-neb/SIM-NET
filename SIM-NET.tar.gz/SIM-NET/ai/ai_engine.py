"""
SIM-NET AI Engine
=================
محرك الذكاء الاصطناعي للتحليل والكشف عن المشاكل
"""

import re
import random
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from collections import Counter

class AIEngine:
    """محرك AI الرئيسي"""
    
    def __init__(self):
        self.knowledge_base = self._initialize_knowledge_base()
        self.threat_signatures = self._initialize_threat_signatures()
        self.packet_patterns = self._initialize_packet_patterns()
        
    def _initialize_knowledge_base(self) -> Dict:
        """تهيئة قاعدة المعرفة"""
        return {
            'packet_issues': {
                'arp_spoofing': {
                    'problem': 'ARP Spoofing Attack',
                    'description': 'MAC address spoofing detected in ARP packets',
                    'solutions': [
                        'Enable Dynamic ARP Inspection (DAI) on all switches',
                        'Configure ARP ACLs for critical devices',
                        'Enable DHCP snooping to validate ARP packets',
                        'Use static ARP entries for critical systems'
                    ],
                    'device_types': ['Switch', 'Router'],
                    'severity': 'High'
                },
                'syn_flood': {
                    'problem': 'SYN Flood Attack',
                    'description': 'High volume of incomplete TCP connections',
                    'solutions': [
                        'Enable TCP Intercept on the router',
                        'Configure SYN cookies on the server',
                        'Implement rate limiting for SYN packets',
                        'Use firewall to block suspicious sources'
                    ],
                    'device_types': ['Router', 'Firewall'],
                    'severity': 'High'
                },
                'icmp_flood': {
                    'problem': 'ICMP Flood / Smurf Attack',
                    'description': 'Excessive ICMP echo requests detected',
                    'solutions': [
                        'Rate limit ICMP traffic on interfaces',
                        'Block directed broadcasts',
                        'Configure ICMP unreachable rate limiting',
                        'Enable ICMP inspection on firewall'
                    ],
                    'device_types': ['Router', 'Firewall'],
                    'severity': 'Medium'
                },
                'malformed_packets': {
                    'problem': 'Malformed Packets',
                    'description': 'Packets with invalid headers or checksums',
                    'solutions': [
                        'Enable packet validation on firewall',
                        'Update IPS signatures',
                        'Check for faulty NICs or cables',
                        'Monitor source devices for malware'
                    ],
                    'device_types': ['Firewall', 'Switch'],
                    'severity': 'Medium'
                },
                'dns_amplification': {
                    'problem': 'DNS Amplification Attack',
                    'description': 'Large DNS responses to spoofed sources',
                    'solutions': [
                        'Restrict DNS recursion to authorized clients',
                        'Rate limit DNS queries',
                        'Block DNS traffic to external resolvers',
                        'Enable DNS response rate limiting (RRL)'
                    ],
                    'device_types': ['DNS Server', 'Firewall'],
                    'severity': 'High'
                }
            },
            'traffic_issues': {
                'bandwidth_abuse': {
                    'problem': 'Bandwidth Abuse',
                    'description': 'Excessive bandwidth consumption by specific hosts',
                    'solutions': [
                        'Implement QoS policies to limit bandwidth',
                        'Identify and investigate top talkers',
                        'Apply traffic shaping on interfaces',
                        'Consider upgrading bandwidth capacity'
                    ],
                    'device_types': ['Router', 'Switch'],
                    'severity': 'Medium'
                },
                'abnormal_patterns': {
                    'problem': 'Abnormal Traffic Patterns',
                    'description': 'Traffic behavior deviates from baseline',
                    'solutions': [
                        'Establish traffic baseline during normal operations',
                        'Enable NetFlow for detailed analysis',
                        'Configure alerts for threshold violations',
                        'Investigate source of anomalous traffic'
                    ],
                    'device_types': ['Router', 'Switch', 'Firewall'],
                    'severity': 'Medium'
                },
                'suspicious_flows': {
                    'problem': 'Suspicious Traffic Flows',
                    'description': 'Unusual connection patterns detected',
                    'solutions': [
                        'Analyze flow data for command & control traffic',
                        'Check for data exfiltration attempts',
                        'Correlate with threat intelligence feeds',
                        'Isolate suspicious hosts for investigation'
                    ],
                    'device_types': ['Firewall', 'IDS/IPS'],
                    'severity': 'High'
                },
                'broadcast_storm': {
                    'problem': 'Broadcast Storm',
                    'description': 'Excessive broadcast/multicast traffic',
                    'solutions': [
                        'Enable storm control on switch ports',
                        'Isolate affected network segment',
                        'Identify and remove looping path',
                        'Enable Spanning Tree Protocol (STP)'
                    ],
                    'device_types': ['Switch'],
                    'severity': 'High'
                }
            },
            'performance_issues': {
                'high_cpu': {
                    'problem': 'High CPU Utilization',
                    'description': 'Device CPU usage critically high',
                    'solutions': [
                        'Identify high CPU processes with "show processes cpu"',
                        'Check for routing loops or broadcast storms',
                        'Optimize routing table size',
                        'Consider hardware upgrade if persistent'
                    ],
                    'device_types': ['Router', 'Switch'],
                    'severity': 'High'
                },
                'high_memory': {
                    'problem': 'High Memory Usage',
                    'description': 'Device memory utilization critically high',
                    'solutions': [
                        'Identify memory-intensive processes',
                        'Check for memory leaks in software',
                        'Reduce routing table or ACL size',
                        'Upgrade device memory if possible'
                    ],
                    'device_types': ['Router', 'Switch'],
                    'severity': 'High'
                },
                'interface_errors': {
                    'problem': 'Interface Errors',
                    'description': 'High number of input/output errors on interface',
                    'solutions': [
                        'Check physical cable connections',
                        'Verify duplex and speed settings match',
                        'Replace faulty cables or SFPs',
                        'Check for electromagnetic interference'
                    ],
                    'device_types': ['Router', 'Switch'],
                    'severity': 'Medium'
                }
            }
        }
    
    def _initialize_threat_signatures(self) -> Dict:
        """تهيئة تواقيع التهديدات"""
        return {
            'arp_spoofing': {
                'indicators': [
                    'gratuitous arp',
                    'arp reply without request',
                    'mac address mismatch'
                ],
                'threshold': 5
            },
            'port_scan': {
                'indicators': [
                    'connection refused',
                    'port unreachable',
                    'syn without ack'
                ],
                'threshold': 20
            },
            'dos_attack': {
                'indicators': [
                    'connection flood',
                    'rate limit exceeded',
                    'resource exhaustion'
                ],
                'threshold': 100
            }
        }
    
    def _initialize_packet_patterns(self) -> Dict:
        """تهيئة أنماط الـ Packets"""
        return {
            'tcp_syn': {'flags': 'S', 'description': 'TCP SYN packet'},
            'tcp_syn_ack': {'flags': 'SA', 'description': 'TCP SYN-ACK packet'},
            'tcp_fin': {'flags': 'F', 'description': 'TCP FIN packet'},
            'tcp_rst': {'flags': 'R', 'description': 'TCP RST packet'},
            'icmp_echo': {'type': 8, 'description': 'ICMP Echo Request'},
            'icmp_reply': {'type': 0, 'description': 'ICMP Echo Reply'},
            'arp_request': {'opcode': 1, 'description': 'ARP Request'},
            'arp_reply': {'opcode': 2, 'description': 'ARP Reply'}
        }
    
    def analyze_packet(self, packet_data: Dict) -> Dict:
        """
        تحليل Packet واحد
        
        Args:
            packet_data: بيانات الـ Packet
            
        Returns:
            نتائج التحليل
        """
        result = {
            'packet_id': packet_data.get('id', 0),
            'timestamp': datetime.now().isoformat(),
            'risk_level': 'Low',
            'threat_type': None,
            'analysis': 'Normal packet',
            'recommendations': [],
            'indicators': []
        }
        
        protocol = packet_data.get('protocol', '').upper()
        source_ip = packet_data.get('source_ip', '')
        dest_ip = packet_data.get('dest_ip', '')
        flags = packet_data.get('flags', '')
        
        # تحليل ARP
        if protocol == 'ARP':
            arp_op = packet_data.get('arp_opcode', 0)
            
            # التحقق من Gratuitous ARP
            if source_ip == dest_ip and arp_op == 2:
                result['risk_level'] = 'Medium'
                result['threat_type'] = 'ARP Spoofing'
                result['analysis'] = 'Gratuitous ARP detected - possible spoofing attempt'
                result['recommendations'] = self.knowledge_base['packet_issues']['arp_spoofing']['solutions'][:3]
                result['indicators'].append('Gratuitous ARP')
            
            # التحقق من MAC Mismatch
            if packet_data.get('mac_mismatch'):
                result['risk_level'] = 'High'
                result['threat_type'] = 'ARP Spoofing'
                result['analysis'] = 'MAC address mismatch detected'
                result['recommendations'] = self.knowledge_base['packet_issues']['arp_spoofing']['solutions']
                result['indicators'].append('MAC Mismatch')
        
        # تحليل TCP
        elif protocol == 'TCP':
            # SYN Flood Detection
            if flags == 'S':
                result['indicators'].append('SYN packet')
                
                # التحقق من حالة الاتصال
                if packet_data.get('incomplete_connection', False):
                    result['risk_level'] = 'High'
                    result['threat_type'] = 'SYN Flood'
                    result['analysis'] = 'Incomplete TCP handshake - possible SYN flood'
                    result['recommendations'] = self.knowledge_base['packet_issues']['syn_flood']['solutions'][:3]
            
            # RST Flood Detection
            if flags == 'R':
                result['indicators'].append('RST packet')
                if packet_data.get('high_rst_rate', False):
                    result['risk_level'] = 'Medium'
                    result['threat_type'] = 'Connection Reset'
                    result['analysis'] = 'High rate of RST packets detected'
        
        # تحليل ICMP
        elif protocol == 'ICMP':
            icmp_type = packet_data.get('icmp_type', 0)
            
            if icmp_type == 8:  # Echo Request
                result['indicators'].append('ICMP Echo')
                
                if packet_data.get('high_volume', False):
                    result['risk_level'] = 'Medium'
                    result['threat_type'] = 'ICMP Flood'
                    result['analysis'] = 'High volume of ICMP echo requests'
                    result['recommendations'] = self.knowledge_base['packet_issues']['icmp_flood']['solutions'][:2]
        
        # تحليل UDP
        elif protocol == 'UDP':
            dest_port = packet_data.get('dest_port', 0)
            
            # DNS Amplification
            if dest_port == 53 and packet_data.get('large_response', False):
                result['risk_level'] = 'High'
                result['threat_type'] = 'DNS Amplification'
                result['analysis'] = 'Large DNS response - possible amplification attack'
                result['recommendations'] = self.knowledge_base['packet_issues']['dns_amplification']['solutions'][:3]
        
        # التحقق من Malformed Packets
        if packet_data.get('malformed', False):
            result['risk_level'] = 'Medium'
            result['threat_type'] = 'Malformed Packet'
            result['analysis'] = 'Packet has invalid structure or checksum'
            result['recommendations'] = self.knowledge_base['packet_issues']['malformed_packets']['solutions'][:2]
            result['indicators'].append('Malformed')
        
        return result
    
    def analyze_traffic(self, traffic_data: Dict) -> Dict:
        """
        تحليل Traffic Patterns
        
        Args:
            traffic_data: بيانات الـ Traffic
            
        Returns:
            نتائج التحليل
        """
        result = {
            'timestamp': datetime.now().isoformat(),
            'risk_level': 'Low',
            'traffic_volume': traffic_data.get('volume', 0),
            'bandwidth_usage': traffic_data.get('bandwidth_percent', 0),
            'analysis': 'Normal traffic pattern',
            'abnormal_patterns': [],
            'recommendations': [],
            'top_talkers': []
        }
        
        volume = traffic_data.get('volume', 0)
        bandwidth = traffic_data.get('bandwidth_percent', 0)
        baseline = traffic_data.get('baseline', {})
        
        # تحليل Bandwidth Usage
        if bandwidth > 90:
            result['risk_level'] = 'High'
            result['abnormal_patterns'].append('Bandwidth saturation')
            result['analysis'] = 'Critical bandwidth utilization detected'
            result['recommendations'] = self.knowledge_base['traffic_issues']['bandwidth_abuse']['solutions']
        elif bandwidth > 70:
            result['risk_level'] = 'Medium'
            result['abnormal_patterns'].append('High bandwidth usage')
            result['analysis'] = 'Above normal bandwidth utilization'
        
        # تحليل Traffic Volume
        if baseline:
            avg_volume = baseline.get('average', 0)
            if avg_volume > 0:
                deviation = abs(volume - avg_volume) / avg_volume * 100
                
                if deviation > 200:
                    result['risk_level'] = 'High'
                    result['abnormal_patterns'].append('Massive traffic spike')
                    result['analysis'] = 'Traffic volume significantly exceeds baseline'
                    result['recommendations'].extend(
                        self.knowledge_base['traffic_issues']['abnormal_patterns']['solutions'][:2]
                    )
                elif deviation > 100:
                    result['risk_level'] = max(result['risk_level'], 'Medium')
                    result['abnormal_patterns'].append('Traffic spike detected')
        
        # تحليل Connection Patterns
        connections = traffic_data.get('connections', [])
        if connections:
            # البحث عن Connection Floods
            conn_per_host = Counter(conn['source_ip'] for conn in connections)
            suspicious_hosts = [ip for ip, count in conn_per_host.items() if count > 100]
            
            if suspicious_hosts:
                result['risk_level'] = 'High'
                result['abnormal_patterns'].append('Connection flood from specific hosts')
                result['top_talkers'] = suspicious_hosts[:5]
                result['recommendations'].extend(
                    self.knowledge_base['traffic_issues']['suspicious_flows']['solutions'][:2]
                )
        
        # تحليل Protocol Distribution
        protocols = traffic_data.get('protocols', {})
        total = sum(protocols.values()) if protocols else 1
        
        icmp_percent = (protocols.get('ICMP', 0) / total) * 100
        if icmp_percent > 20:
            result['risk_level'] = max(result['risk_level'], 'Medium')
            result['abnormal_patterns'].append(f'High ICMP traffic ({icmp_percent:.1f}%)')
        
        udp_percent = (protocols.get('UDP', 0) / total) * 100
        if udp_percent > 50:
            result['abnormal_patterns'].append(f'Unusual UDP dominance ({udp_percent:.1f}%)')
        
        # تحليل Broadcast Traffic
        broadcast_percent = traffic_data.get('broadcast_percent', 0)
        if broadcast_percent > 10:
            result['risk_level'] = 'High'
            result['abnormal_patterns'].append('Broadcast storm detected')
            result['analysis'] = 'Excessive broadcast traffic - possible loop'
            result['recommendations'] = self.knowledge_base['traffic_issues']['broadcast_storm']['solutions']
        
        return result
    
    def detect_anomalies(self, data_points: List[Dict]) -> List[Dict]:
        """
        اكتشاف الشذوذ في البيانات
        
        Args:
            data_points: قائمة نقاط البيانات
            
        Returns:
            قائمة بالشواذ المكتشفة
        """
        if len(data_points) < 3:
            return []
        
        anomalies = []
        
        # حساب المتوسط والانحراف المعياري
        values = [dp.get('value', 0) for dp in data_points]
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        std_dev = variance ** 0.5
        
        # اكتشاف الشواذ (أكثر من 2 انحراف معياري)
        for dp in data_points:
            value = dp.get('value', 0)
            z_score = abs(value - mean) / std_dev if std_dev > 0 else 0
            
            if z_score > 2:
                anomalies.append({
                    'timestamp': dp.get('timestamp'),
                    'value': value,
                    'expected_range': [mean - 2*std_dev, mean + 2*std_dev],
                    'z_score': z_score,
                    'severity': 'High' if z_score > 3 else 'Medium'
                })
        
        return anomalies
    
    def get_solutions(self, problem_type: str, device_type: str = None) -> List[Dict]:
        """
        الحصول على حلول لمشكلة معينة
        
        Args:
            problem_type: نوع المشكلة
            device_type: نوع الجهاز (اختياري)
            
        Returns:
            قائمة بالحلول المتاحة
        """
        solutions = []
        
        # البحث في جميع الفئات
        for category, issues in self.knowledge_base.items():
            for issue_key, issue_data in issues.items():
                if problem_type.lower() in issue_key.lower() or \
                   problem_type.lower() in issue_data['problem'].lower():
                    
                    # التحقق من نوع الجهاز
                    if device_type and device_type not in issue_data.get('device_types', []):
                        continue
                    
                    solutions.append({
                        'problem': issue_data['problem'],
                        'description': issue_data['description'],
                        'solutions': issue_data['solutions'],
                        'severity': issue_data['severity'],
                        'category': category
                    })
        
        return solutions
    
    def chatbot_assist(self, query: str, context: Dict = None) -> Dict:
        """
        مساعد Chatbot للمشاكل
        
        Args:
            query: استفسار المستخدم
            context: سياق إضافي
            
        Returns:
            رد Chatbot
        """
        query_lower = query.lower()
        response = {
            'query': query,
            'timestamp': datetime.now().isoformat(),
            'problem_detected': False,
            'solutions': [],
            'suggestions': [],
            'related_issues': []
        }
        
        # كلمات مفتاحية للمشاكل الشائعة
        keywords = {
            'interface down': ['interface', 'down', 'link', 'port'],
            'high cpu': ['cpu', 'high', 'load', 'process'],
            'slow network': ['slow', 'latency', 'delay', 'speed'],
            'connection issue': ['connect', 'timeout', 'unreachable'],
            'security alert': ['attack', 'threat', 'intrusion', 'hack'],
            'vlan problem': ['vlan', 'tagging', 'trunk'],
            'routing issue': ['route', 'routing', 'path', 'gateway'],
            'dhcp problem': ['dhcp', 'ip address', 'lease'],
            'dns issue': ['dns', 'resolve', 'name', 'domain'],
            'bandwidth': ['bandwidth', 'traffic', 'congestion']
        }
        
        # البحث عن أفضل تطابق
        best_match = None
        best_score = 0
        
        for issue_type, words in keywords.items():
            score = sum(1 for word in words if word in query_lower)
            if score > best_score:
                best_score = score
                best_match = issue_type
        
        if best_match and best_score >= 1:
            response['problem_detected'] = True
            
            # الحصول على الحلول
            if best_match == 'interface down':
                response['solutions'] = [
                    '1. Check physical cable connections and LED indicators',
                    '2. Verify interface status with "show ip interface brief"',
                    '3. Try "shutdown" then "no shutdown" to restart interface',
                    '4. Check for errors with "show interfaces"',
                    '5. Verify duplex and speed settings match on both ends'
                ]
                response['severity'] = 'Medium'
            
            elif best_match == 'high cpu':
                response['solutions'] = [
                    '1. Identify high CPU processes with "show processes cpu"',
                    '2. Check for routing loops or broadcast storms',
                    '3. Verify no debug commands are running',
                    '4. Optimize routing table if too large',
                    '5. Consider hardware upgrade if consistently high'
                ]
                response['severity'] = 'High'
            
            elif best_match == 'slow network':
                response['solutions'] = [
                    '1. Check interface counters for errors or drops',
                    '2. Test latency with extended ping tests',
                    '3. Verify duplex and speed settings match',
                    '4. Check for bandwidth saturation during peak hours',
                    '5. Review QoS policies and traffic shaping'
                ]
                response['severity'] = 'Medium'
            
            elif best_match == 'security alert':
                response['solutions'] = [
                    '1. Identify the source of the attack/threat',
                    '2. Apply ACLs to block malicious traffic',
                    '3. Enable additional logging for investigation',
                    '4. Consider isolating affected segment',
                    '5. Review and update security policies'
                ]
                response['severity'] = 'High'
            
            elif best_match == 'vlan problem':
                response['solutions'] = [
                    '1. Verify VLAN configuration with "show vlan brief"',
                    '2. Check trunk ports allow required VLANs',
                    '3. Verify access ports assigned to correct VLAN',
                    '4. Check native VLAN mismatch on trunks',
                    '5. Verify VTP configuration if using VTP'
                ]
                response['severity'] = 'Medium'
            
            elif best_match == 'routing issue':
                response['solutions'] = [
                    '1. Check routing table with "show ip route"',
                    '2. Verify routing protocol neighbors are established',
                    '3. Check for route flapping in logs',
                    '4. Verify next-hop reachability',
                    '5. Check for blackholes or routing loops'
                ]
                response['severity'] = 'High'
            
            elif best_match == 'bandwidth':
                response['solutions'] = [
                    '1. Identify top bandwidth consumers with NetFlow',
                    '2. Implement QoS policies for critical traffic',
                    '3. Apply traffic shaping on interfaces',
                    '4. Consider bandwidth upgrade if consistently saturated',
                    '5. Review and optimize application traffic patterns'
                ]
                response['severity'] = 'Medium'
            
            else:
                # رد افتراضي
                response['solutions'] = [
                    '1. Gather more information about the issue',
                    '2. Check device logs for error messages',
                    '3. Verify recent configuration changes',
                    '4. Test connectivity step by step',
                    '5. Consider restarting affected services'
                ]
                response['severity'] = 'Low'
            
            # إضافة اقتراحات ذات صلة
            response['related_issues'] = self._get_related_issues(best_match)
        
        else:
            # لم يتم التعرف على المشكلة
            response['suggestions'] = [
                'Please provide more details about:',
                '- Device type (Router/Switch/Server)',
                '- Specific error messages',
                '- When the problem started',
                '- Any recent changes made',
                '- Impact on network/users'
            ]
        
        return response
    
    def _get_related_issues(self, issue_type: str) -> List[str]:
        """الحصول على مشاكل ذات صلة"""
        related = {
            'interface down': ['High interface errors', 'Duplex mismatch', 'Cable fault'],
            'high cpu': ['High memory usage', 'Process crash', 'Routing loop'],
            'slow network': ['High latency', 'Packet loss', 'Bandwidth saturation'],
            'security alert': ['ACL violation', 'Authentication failure', 'Port scan'],
            'vlan problem': ['Trunk misconfiguration', 'VTP issue', 'Native VLAN mismatch'],
            'routing issue': ['BGP flap', 'OSPF neighbor down', 'Blackhole route'],
            'bandwidth': ['QoS misconfiguration', 'Traffic spike', 'DDoS attack']
        }
        return related.get(issue_type, [])
    
    def generate_report(self, analysis_type: str, data: Dict) -> Dict:
        """توليد تقرير تحليلي"""
        return {
            'report_type': analysis_type,
            'generated_at': datetime.now().isoformat(),
            'summary': data.get('summary', 'No summary available'),
            'findings': data.get('findings', []),
            'recommendations': data.get('recommendations', []),
            'risk_assessment': data.get('risk_assessment', 'Low'),
            'next_steps': data.get('next_steps', [])
        }


# ==================== دوال مساعدة ====================

def calculate_entropy(data: bytes) -> float:
    """حساب Entropy للبيانات (للكشف عن التشفير)"""
    if not data:
        return 0
    
    entropy = 0
    for x in range(256):
        p_x = float(data.count(bytes([x]))) / len(data)
        if p_x > 0:
            entropy += - p_x * (p_x).bit_length()
    
    return entropy

def is_encrypted_traffic(packet_data: Dict) -> bool:
    """التحقق مما إذا كان الـ Traffic مشفراً"""
    port = packet_data.get('dest_port', 0)
    encrypted_ports = [443, 22, 993, 995, 465, 587]
    return port in encrypted_ports


# ==================== اختبار ====================

if __name__ == '__main__':
    ai = AIEngine()
    
    # اختبار تحليل Packet
    packet = {
        'id': 1,
        'protocol': 'ARP',
        'source_ip': '192.168.1.10',
        'dest_ip': '192.168.1.10',
        'arp_opcode': 2,
        'mac_mismatch': True
    }
    
    result = ai.analyze_packet(packet)
    print("Packet Analysis:")
    print(f"  Risk: {result['risk_level']}")
    print(f"  Threat: {result['threat_type']}")
    print(f"  Analysis: {result['analysis']}")
    
    # اختبار Chatbot
    print("\nChatbot Test:")
    response = ai.chatbot_assist("My interface is down")
    print(f"  Problem detected: {response['problem_detected']}")
    print(f"  Solutions: {len(response['solutions'])}")
