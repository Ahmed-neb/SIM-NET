"""
SIM-NET Database Module
=======================
إدارة قاعدة البيانات
"""

from .db_manager import (
    init_database,
    seed_initial_data,
    get_connection,
    add_user,
    get_user_by_username,
    get_user_by_id,
    get_all_users,
    update_last_login,
    add_log,
    add_device,
    get_all_devices,
    get_device_by_id,
    update_device_status,
    delete_device,
    add_performance_data,
    get_performance_data,
    add_backup,
    get_backups,
    add_security_issue,
    get_security_issues,
    add_packet_analysis,
    add_traffic_analysis,
    get_knowledge_base_solutions,
    add_alert,
    get_alerts,
    mark_alert_read,
    get_all_logs,
    get_logs_by_severity
)

__all__ = [
    'init_database',
    'seed_initial_data',
    'get_connection',
    'add_user',
    'get_user_by_username',
    'get_user_by_id',
    'get_all_users',
    'update_last_login',
    'add_log',
    'add_device',
    'get_all_devices',
    'get_device_by_id',
    'update_device_status',
    'delete_device',
    'add_performance_data',
    'get_performance_data',
    'add_backup',
    'get_backups',
    'add_security_issue',
    'get_security_issues',
    'add_packet_analysis',
    'add_traffic_analysis',
    'get_knowledge_base_solutions',
    'add_alert',
    'get_alerts',
    'mark_alert_read',
    'get_all_logs',
    'get_logs_by_severity'
]
