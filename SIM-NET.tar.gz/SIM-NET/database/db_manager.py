"""
SIM-NET Database Manager
========================
إدارة قاعدة البيانات SQLite للنظام
"""

import sqlite3
import os
from datetime import datetime
from pathlib import Path

# مسار قاعدة البيانات
DB_PATH = Path(__file__).parent / "network.db"

def get_connection():
    """إنشاء اتصال بقاعدة البيانات"""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_database():
    """تهيئة قاعدة البيانات وإنشاء جميع الجداول"""
    conn = get_connection()
    cursor = conn.cursor()
    
    # جدول المستخدمين
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'viewer',
            email TEXT,
            phone TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP,
            is_active INTEGER DEFAULT 1
        )
    ''')
    
    # جدول جلسات المستخدمين
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            logout_time TIMESTAMP,
            ip_address TEXT,
            session_token TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # جدول الأجهزة
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip_address TEXT UNIQUE NOT NULL,
            hostname TEXT,
            device_type TEXT,
            vendor TEXT,
            os_version TEXT,
            username TEXT,
            password TEXT,
            enable_password TEXT,
            location TEXT,
            status TEXT DEFAULT 'unknown',
            last_seen TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            created_by INTEGER,
            FOREIGN KEY (created_by) REFERENCES users(id)
        )
    ''')
    
    # جدول Interfaces
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS interfaces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER,
            interface_name TEXT,
            status TEXT,
            protocol TEXT,
            ip_address TEXT,
            last_check TIMESTAMP,
            FOREIGN KEY (device_id) REFERENCES devices(id)
        )
    ''')
    
    # جدول المهام
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_name TEXT NOT NULL,
            task_type TEXT,
            description TEXT,
            schedule_time TEXT,
            status TEXT DEFAULT 'pending',
            created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_run TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users(id)
        )
    ''')
    
    # جدول تنفيذ المهام
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS task_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER,
            device_id INTEGER,
            status TEXT,
            output TEXT,
            error_message TEXT,
            executed_by INTEGER,
            executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (task_id) REFERENCES tasks(id),
            FOREIGN KEY (device_id) REFERENCES devices(id),
            FOREIGN KEY (executed_by) REFERENCES users(id)
        )
    ''')
    
    # جدول النسخ الاحتياطية
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS backups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER,
            backup_type TEXT,
            file_path TEXT,
            file_size INTEGER,
            config_content TEXT,
            performed_by INTEGER,
            backup_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            notes TEXT,
            FOREIGN KEY (device_id) REFERENCES devices(id),
            FOREIGN KEY (performed_by) REFERENCES users(id)
        )
    ''')
    
    # جدول اللوجز
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT,
            event_category TEXT,
            description TEXT,
            user_id INTEGER,
            device_id INTEGER,
            severity TEXT DEFAULT 'info',
            ip_address TEXT,
            details TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (device_id) REFERENCES devices(id)
        )
    ''')
    
    # جدول الأداء
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS performance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER,
            cpu_usage REAL,
            memory_usage REAL,
            disk_usage REAL,
            latency REAL,
            packet_loss REAL,
            interface_stats TEXT,
            collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (device_id) REFERENCES devices(id)
        )
    ''')
    
    # جدول الأمان - المشاكل
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS security_issues (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER,
            issue_type TEXT,
            severity TEXT,
            description TEXT,
            source_ip TEXT,
            target_ip TEXT,
            attack_type TEXT,
            status TEXT DEFAULT 'open',
            solution TEXT,
            detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            resolved_at TIMESTAMP,
            resolved_by INTEGER,
            FOREIGN KEY (device_id) REFERENCES devices(id),
            FOREIGN KEY (resolved_by) REFERENCES users(id)
        )
    ''')
    
    # جدول AI - Packet Analysis
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS packet_analysis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER,
            packet_data TEXT,
            risk_level TEXT,
            threat_type TEXT,
            source_ip TEXT,
            destination_ip TEXT,
            protocol TEXT,
            analysis_result TEXT,
            recommended_action TEXT,
            analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (device_id) REFERENCES devices(id)
        )
    ''')
    
    # جدول AI - Traffic Analysis
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS traffic_analysis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER,
            traffic_volume REAL,
            bandwidth_usage REAL,
            abnormal_patterns TEXT,
            risk_level TEXT,
            source_analysis TEXT,
            recommendations TEXT,
            analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (device_id) REFERENCES devices(id)
        )
    ''')
    
    # جدول AI - Knowledge Base
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ai_knowledge_base (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            problem_type TEXT,
            problem_description TEXT,
            solution_1 TEXT,
            solution_2 TEXT,
            solution_3 TEXT,
            device_type TEXT,
            success_count INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # جدول VLANs
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vlans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER,
            vlan_number INTEGER,
            vlan_name TEXT,
            ports TEXT,
            created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (device_id) REFERENCES devices(id),
            FOREIGN KEY (created_by) REFERENCES users(id)
        )
    ''')
    
    # جدول ACLs
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS acls (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER,
            acl_name TEXT,
            acl_rules TEXT,
            applied_interface TEXT,
            direction TEXT,
            created_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (device_id) REFERENCES devices(id),
            FOREIGN KEY (created_by) REFERENCES users(id)
        )
    ''')
    
    # جدول التنبيهات
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alert_type TEXT,
            severity TEXT,
            title TEXT,
            message TEXT,
            device_id INTEGER,
            is_read INTEGER DEFAULT 0,
            sent_email INTEGER DEFAULT 0,
            sent_sms INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (device_id) REFERENCES devices(id)
        )
    ''')
    
    # جدول الأجهزة المتصلة مؤقتاً
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS connected_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id INTEGER,
            user_id INTEGER,
            connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            disconnected_at TIMESTAMP,
            session_data TEXT,
            FOREIGN KEY (device_id) REFERENCES devices(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ Database initialized successfully!")

# ==================== دوال المستخدمين ====================

def add_user(username, password, role='viewer', email=None, phone=None):
    """إضافة مستخدم جديد"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO users (username, password, role, email, phone)
            VALUES (?, ?, ?, ?, ?)
        ''', (username, password, role, email, phone))
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()

def get_user_by_username(username):
    """الحصول على مستخدم بواسطة الاسم"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    conn.close()
    return dict(user) if user else None

def get_user_by_id(user_id):
    """الحصول على مستخدم بواسطة ID"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    return dict(user) if user else None

def get_all_users():
    """الحصول على جميع المستخدمين"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, username, role, email, created_at, last_login, is_active FROM users')
    users = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return users

def update_last_login(user_id):
    """تحديث وقت آخر دخول"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET last_login = ? WHERE id = ?', 
                   (datetime.now(), user_id))
    conn.commit()
    conn.close()

def delete_user(user_id):
    """حذف مستخدم"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM users WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()

# ==================== دوال الأجهزة ====================

def add_device(ip_address, hostname, device_type, vendor, os_version, 
               username=None, password=None, enable_password=None, 
               location=None, created_by=None):
    """إضافة جهاز جديد"""
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute('''
            INSERT INTO devices (ip_address, hostname, device_type, vendor, os_version,
                               username, password, enable_password, location, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (ip_address, hostname, device_type, vendor, os_version,
              username, password, enable_password, location, created_by))
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()

def get_all_devices():
    """الحصول على جميع الأجهزة"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM devices ORDER BY created_at DESC')
    devices = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return devices

def get_device_by_id(device_id):
    """الحصول على جهاز بواسطة ID"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM devices WHERE id = ?', (device_id,))
    device = cursor.fetchone()
    conn.close()
    return dict(device) if device else None

def get_device_by_ip(ip_address):
    """الحصول على جهاز بواسطة IP"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM devices WHERE ip_address = ?', (ip_address,))
    device = cursor.fetchone()
    conn.close()
    return dict(device) if device else None

def update_device_status(device_id, status):
    """تحديث حالة الجهاز"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE devices SET status = ?, last_seen = ? WHERE id = ?
    ''', (status, datetime.now(), device_id))
    conn.commit()
    conn.close()

def delete_device(device_id):
    """حذف جهاز"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM devices WHERE id = ?', (device_id,))
    conn.commit()
    conn.close()

# ==================== دوال اللوجز ====================

def add_log(event_type, description, user_id=None, device_id=None, 
            severity='info', ip_address=None, details=None):
    """إضافة سجل جديد"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO logs (event_type, description, user_id, device_id, severity, ip_address, details)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (event_type, description, user_id, device_id, severity, ip_address, details))
    conn.commit()
    conn.close()

def get_all_logs(limit=100):
    """الحصول على السجلات"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT l.*, u.username, d.hostname 
        FROM logs l
        LEFT JOIN users u ON l.user_id = u.id
        LEFT JOIN devices d ON l.device_id = d.id
        ORDER BY l.created_at DESC
        LIMIT ?
    ''', (limit,))
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return logs

def get_logs_by_severity(severity):
    """الحصول على السجلات حسب الخطورة"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT l.*, u.username, d.hostname 
        FROM logs l
        LEFT JOIN users u ON l.user_id = u.id
        LEFT JOIN devices d ON l.device_id = d.id
        WHERE l.severity = ?
        ORDER BY l.created_at DESC
    ''', (severity,))
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return logs

# ==================== دوال الأداء ====================

def add_performance_data(device_id, cpu_usage, memory_usage, disk_usage,
                         latency=None, packet_loss=None, interface_stats=None):
    """إضافة بيانات الأداء"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO performance (device_id, cpu_usage, memory_usage, disk_usage,
                               latency, packet_loss, interface_stats)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (device_id, cpu_usage, memory_usage, disk_usage, 
          latency, packet_loss, interface_stats))
    conn.commit()
    conn.close()

def get_performance_data(device_id=None, limit=100):
    """الحصول على بيانات الأداء"""
    conn = get_connection()
    cursor = conn.cursor()
    if device_id:
        cursor.execute('''
            SELECT p.*, d.hostname, d.ip_address
            FROM performance p
            JOIN devices d ON p.device_id = d.id
            WHERE p.device_id = ?
            ORDER BY p.collected_at DESC
            LIMIT ?
        ''', (device_id, limit))
    else:
        cursor.execute('''
            SELECT p.*, d.hostname, d.ip_address
            FROM performance p
            JOIN devices d ON p.device_id = d.id
            ORDER BY p.collected_at DESC
            LIMIT ?
        ''', (limit,))
    data = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return data

# ==================== دوال النسخ الاحتياطي ====================

def add_backup(device_id, backup_type, file_path, file_size=None,
               config_content=None, performed_by=None, notes=None):
    """إضافة نسخة احتياطية"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO backups (device_id, backup_type, file_path, file_size,
                           config_content, performed_by, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (device_id, backup_type, file_path, file_size,
          config_content, performed_by, notes))
    conn.commit()
    conn.close()

def get_backups(device_id=None):
    """الحصول على النسخ الاحتياطية"""
    conn = get_connection()
    cursor = conn.cursor()
    if device_id:
        cursor.execute('''
            SELECT b.*, d.hostname, d.ip_address, u.username as performer
            FROM backups b
            JOIN devices d ON b.device_id = d.id
            LEFT JOIN users u ON b.performed_by = u.id
            WHERE b.device_id = ?
            ORDER BY b.backup_date DESC
        ''', (device_id,))
    else:
        cursor.execute('''
            SELECT b.*, d.hostname, d.ip_address, u.username as performer
            FROM backups b
            JOIN devices d ON b.device_id = d.id
            LEFT JOIN users u ON b.performed_by = u.id
            ORDER BY b.backup_date DESC
        ''')
    backups = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return backups

# ==================== دوال الأمان ====================

def add_security_issue(device_id, issue_type, severity, description,
                       source_ip=None, target_ip=None, attack_type=None, solution=None):
    """إضافة مشكلة أمان"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO security_issues (device_id, issue_type, severity, description,
                                   source_ip, target_ip, attack_type, solution)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (device_id, issue_type, severity, description,
          source_ip, target_ip, attack_type, solution))
    conn.commit()
    conn.close()

def get_security_issues(status='open'):
    """الحصول على مشاكل الأمان"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT s.*, d.hostname, d.ip_address
        FROM security_issues s
        JOIN devices d ON s.device_id = d.id
        WHERE s.status = ?
        ORDER BY s.detected_at DESC
    ''', (status,))
    issues = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return issues

def resolve_security_issue(issue_id, resolved_by):
    """حل مشكلة أمان"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE security_issues 
        SET status = 'resolved', resolved_at = ?, resolved_by = ?
        WHERE id = ?
    ''', (datetime.now(), resolved_by, issue_id))
    conn.commit()
    conn.close()

# ==================== دوال AI ====================

def add_packet_analysis(device_id, packet_data, risk_level, threat_type,
                        source_ip, destination_ip, protocol, 
                        analysis_result, recommended_action):
    """إضافة تحليل Packet"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO packet_analysis (device_id, packet_data, risk_level, threat_type,
                                   source_ip, destination_ip, protocol,
                                   analysis_result, recommended_action)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (device_id, packet_data, risk_level, threat_type,
          source_ip, destination_ip, protocol,
          analysis_result, recommended_action))
    conn.commit()
    conn.close()

def add_traffic_analysis(device_id, traffic_volume, bandwidth_usage,
                         abnormal_patterns, risk_level, source_analysis, recommendations):
    """إضافة تحليل Traffic"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO traffic_analysis (device_id, traffic_volume, bandwidth_usage,
                                    abnormal_patterns, risk_level, source_analysis, recommendations)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (device_id, traffic_volume, bandwidth_usage,
          abnormal_patterns, risk_level, source_analysis, recommendations))
    conn.commit()
    conn.close()

def add_to_knowledge_base(problem_type, problem_description, solution_1, 
                          solution_2, solution_3, device_type):
    """إضافة إلى قاعدة المعرفة"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO ai_knowledge_base (problem_type, problem_description, 
                                     solution_1, solution_2, solution_3, device_type)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (problem_type, problem_description, solution_1, solution_2, solution_3, device_type))
    conn.commit()
    conn.close()

def get_knowledge_base_solutions(problem_type, device_type=None):
    """الحصول على حلول من قاعدة المعرفة"""
    conn = get_connection()
    cursor = conn.cursor()
    if device_type:
        cursor.execute('''
            SELECT * FROM ai_knowledge_base
            WHERE problem_type = ? AND device_type = ?
            ORDER BY success_count DESC
        ''', (problem_type, device_type))
    else:
        cursor.execute('''
            SELECT * FROM ai_knowledge_base
            WHERE problem_type = ?
            ORDER BY success_count DESC
        ''', (problem_type,))
    solutions = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return solutions

# ==================== دوال التنبيهات ====================

def add_alert(alert_type, severity, title, message, device_id=None):
    """إضافة تنبيه"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO alerts (alert_type, severity, title, message, device_id)
        VALUES (?, ?, ?, ?, ?)
    ''', (alert_type, severity, title, message, device_id))
    conn.commit()
    conn.close()

def get_alerts(unread_only=False):
    """الحصول على التنبيهات"""
    conn = get_connection()
    cursor = conn.cursor()
    if unread_only:
        cursor.execute('''
            SELECT a.*, d.hostname, d.ip_address
            FROM alerts a
            LEFT JOIN devices d ON a.device_id = d.id
            WHERE a.is_read = 0
            ORDER BY a.created_at DESC
        ''')
    else:
        cursor.execute('''
            SELECT a.*, d.hostname, d.ip_address
            FROM alerts a
            LEFT JOIN devices d ON a.device_id = d.id
            ORDER BY a.created_at DESC
        ''')
    alerts = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return alerts

def mark_alert_read(alert_id):
    """تحديد التنبيه كمقروء"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE alerts SET is_read = 1 WHERE id = ?', (alert_id,))
    conn.commit()
    conn.close()

# ==================== تهيئة البيانات الأولية ====================

def seed_initial_data():
    """إضافة بيانات أولية للنظام"""
    conn = get_connection()
    cursor = conn.cursor()
    
    # إضافة مستخدم admin افتراضي
    cursor.execute('''
        INSERT OR IGNORE INTO users (id, username, password, role, email)
        VALUES (1, 'admin', 'admin123', 'admin', 'admin@simnet.local')
    ''')
    
    # إضافة مستخدم engineer افتراضي
    cursor.execute('''
        INSERT OR IGNORE INTO users (id, username, password, role, email)
        VALUES (2, 'engineer', 'engineer123', 'engineer', 'engineer@simnet.local')
    ''')
    
    # إضافة مستخدم viewer افتراضي
    cursor.execute('''
        INSERT OR IGNORE INTO users (id, username, password, role, email)
        VALUES (3, 'viewer', 'viewer123', 'viewer', 'viewer@simnet.local')
    ''')
    
    # إضافة بيانات لقاعدة المعرفة
    knowledge_data = [
        ('ARP Spoofing', 'ARP spoofing attack detected on network', 
         'Enable Dynamic ARP Inspection (DAI)', 
         'Configure static ARP entries',
         'Enable ARP inspection on switch', 'Switch'),
        ('DoS Attack', 'Denial of Service attack detected',
         'Enable rate limiting on interfaces',
         'Configure ACL to block source IP',
         'Enable TCP intercept', 'Router'),
        ('Port Scan', 'Port scanning activity detected',
         'Enable port security on switch ports',
         'Configure IPS to detect scans',
         'Enable storm control', 'Switch'),
        ('High CPU', 'Device CPU usage is critically high',
         'Identify and terminate high CPU processes',
         'Upgrade device hardware',
         'Optimize routing table', 'Router'),
        ('Interface Down', 'Critical interface is down',
         'Check physical cable connections',
         'Restart interface using shutdown/no shutdown',
         'Replace faulty hardware', 'Router'),
    ]
    
    for data in knowledge_data:
        cursor.execute('''
            INSERT OR IGNORE INTO ai_knowledge_base 
            (problem_type, problem_description, solution_1, solution_2, solution_3, device_type)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', data)
    
    conn.commit()
    conn.close()
    print("✅ Initial data seeded!")

# ==================== تشغيل التهيئة ====================

if __name__ == '__main__':
    init_database()
    seed_initial_data()
    print("✅ Database setup complete!")
