"""
SIM-NET Configuration
=====================
إعدادات النظام
"""

import os
from pathlib import Path

# Base paths
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
BACKUP_DIR = BASE_DIR / "backups"
REPORT_DIR = BASE_DIR / "reports"
LOG_DIR = BASE_DIR / "logs"

# Create directories if not exist
for dir_path in [DATA_DIR, BACKUP_DIR, REPORT_DIR, LOG_DIR]:
    dir_path.mkdir(exist_ok=True)

# Database
DB_PATH = DATA_DIR / "network.db"

# Flask Configuration
class Config:
    """إعدادات Flask الأساسية"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'simnet-secret-key-2024-change-in-production'
    
    # Session
    PERMANENT_SESSION_LIFETIME = 3600  # 1 hour
    
    # CORS
    CORS_ORIGINS = ['http://localhost:8080', 'http://127.0.0.1:8080']
    
    # File uploads
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    
    # Logging
    LOG_LEVEL = 'INFO'
    LOG_FILE = LOG_DIR / 'simnet.log'

class DevelopmentConfig(Config):
    """إعدادات بيئة التطوير"""
    DEBUG = True
    LOG_LEVEL = 'DEBUG'

class ProductionConfig(Config):
    """إعدادات بيئة الإنتاج"""
    DEBUG = False
    LOG_LEVEL = 'WARNING'
    
    # In production, use environment variable
    SECRET_KEY = os.environ.get('SECRET_KEY')
    
    if not SECRET_KEY:
        raise ValueError("SECRET_KEY environment variable must be set in production")

# Config dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}

# Network Configuration
NETWORK_CONFIG = {
    # Default credentials for testing (change in production)
    'default_username': 'admin',
    'default_password': 'admin',
    'default_enable_password': 'admin',
    
    # Telnet settings
    'telnet_timeout': 10,
    'telnet_port': 23,
    
    # SSH settings
    'ssh_timeout': 10,
    'ssh_port': 22,
    
    # Monitoring settings
    'ping_count': 4,
    'ping_timeout': 5,
    
    # Auto-healing settings
    'auto_heal_enabled': True,
    'interface_restart_delay': 5,
    
    # Backup settings
    'backup_interval_hours': 24,
    'backup_retention_days': 30,
    
    # Alert settings
    'alert_cooldown_minutes': 15,
    'email_alerts_enabled': False,
    'sms_alerts_enabled': False
}

# Security Configuration
SECURITY_CONFIG = {
    # Password policy
    'min_password_length': 8,
    'require_special_chars': True,
    'password_expiry_days': 90,
    
    # Login protection
    'max_login_attempts': 5,
    'lockout_duration_minutes': 30,
    
    # Session settings
    'session_timeout_minutes': 60,
    'require_reauth_for_sensitive': True,
    
    # API rate limiting
    'rate_limit_requests': 100,
    'rate_limit_window': 3600  # 1 hour
}

# AI Configuration
AI_CONFIG = {
    # Packet analysis
    'packet_analysis_enabled': True,
    'threat_detection_threshold': 0.7,
    
    # Traffic analysis
    'traffic_baseline_hours': 24,
    'anomaly_detection_sensitivity': 2.0,  # Standard deviations
    
    # Chatbot
    'chatbot_enabled': True,
    'max_chat_history': 50,
    
    # Knowledge base
    'auto_update_knowledge_base': True,
    'min_confidence_for_auto_solution': 0.8
}

# Device Types
DEVICE_TYPES = {
    'Router': {
        'icon': 'router',
        'commands': ['show version', 'show ip interface brief', 'show running-config'],
        'common_vendors': ['Cisco', 'Juniper', 'Huawei', 'HP']
    },
    'Switch': {
        'icon': 'network-wired',
        'commands': ['show version', 'show vlan brief', 'show mac address-table'],
        'common_vendors': ['Cisco', 'Juniper', 'Huawei', 'HP', 'D-Link']
    },
    'Server': {
        'icon': 'server',
        'commands': ['uname -a', 'df -h', 'top -b -n 1'],
        'common_vendors': ['HP', 'Dell', 'IBM', 'Supermicro']
    },
    'Firewall': {
        'icon': 'shield-alt',
        'commands': ['show version', 'show conn count', 'show access-list'],
        'common_vendors': ['Cisco', 'Palo Alto', 'Fortinet', 'Juniper']
    }
}

# Severity Levels
SEVERITY_LEVELS = {
    'critical': {'color': '#ef4444', 'priority': 1, 'notify': True},
    'high': {'color': '#f97316', 'priority': 2, 'notify': True},
    'medium': {'color': '#f59e0b', 'priority': 3, 'notify': False},
    'low': {'color': '#10b981', 'priority': 4, 'notify': False},
    'info': {'color': '#06b6d4', 'priority': 5, 'notify': False}
}

# Report Templates
REPORT_TEMPLATES = {
    'daily': {
        'title': 'Daily Network Report',
        'sections': ['summary', 'devices', 'alerts', 'performance'],
        'format': 'html'
    },
    'weekly': {
        'title': 'Weekly Network Report',
        'sections': ['summary', 'devices', 'alerts', 'performance', 'security', 'recommendations'],
        'format': 'pdf'
    },
    'monthly': {
        'title': 'Monthly Network Report',
        'sections': ['summary', 'devices', 'alerts', 'performance', 'security', 'trends', 'recommendations'],
        'format': 'pdf'
    }
}

# Export formats
EXPORT_FORMATS = ['json', 'csv', 'excel', 'pdf']

# Default admin credentials (change in production!)
DEFAULT_ADMIN = {
    'username': 'admin',
    'password': 'admin123',
    'email': 'admin@simnet.local',
    'role': 'admin'
}

# Get current config
def get_config(env=None):
    """الحصول على الإعدادات الحالية"""
    env = env or os.environ.get('FLASK_ENV', 'development')
    return config.get(env, config['default'])
