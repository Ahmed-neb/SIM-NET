"""
SIM-NET Backend API
===================
الواجهة الخلفية للنظام باستخدام Flask
"""

from flask import Flask, request, jsonify, session, send_file
from flask_cors import CORS
from functools import wraps
import os
import sys
import json
import subprocess
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

# إضافة المسارات
sys.path.append(str(Path(__file__).parent.parent))

from database.db_manager import (
    init_database, seed_initial_data, get_connection,
    add_user, get_user_by_username, get_user_by_id, get_all_users,
    update_last_login, add_log, add_device, get_all_devices, 
    get_device_by_id, update_device_status, delete_device,
    add_performance_data, get_performance_data,
    add_backup, get_backups, add_security_issue, get_security_issues,
    add_packet_analysis, add_traffic_analysis, get_knowledge_base_solutions,
    add_alert, get_alerts, mark_alert_read, get_all_logs
)

app = Flask(__name__)
app.secret_key = 'simnet-secret-key-2024-secure-network-management'
CORS(app, supports_credentials=True)

# ==================== Middleware ====================

def login_required(f):
    """تأكد من تسجيل الدخول"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Unauthorized - Please login'}), 401
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    """تأكد من أن المستخدم admin"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Unauthorized'}), 401
        user = get_user_by_id(session['user_id'])
        if not user or user['role'] != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return decorated_function

def engineer_required(f):
    """تأكد من أن المستخدم engineer أو admin"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Unauthorized'}), 401
        user = get_user_by_id(session['user_id'])
        if not user or user['role'] not in ['admin', 'engineer']:
            return jsonify({'error': 'Engineer access required'}), 403
        return f(*args, **kwargs)
    return decorated_function

# ==================== Routes ====================

@app.route('/')
def index():
    return jsonify({
        'name': 'SIM-NET API',
        'version': '1.0.0',
        'status': 'running',
        'timestamp': datetime.now().isoformat()
    })

# ==================== Authentication Routes ====================

@app.route('/api/auth/login', methods=['POST'])
def login():
    """تسجيل الدخول"""
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    user = get_user_by_username(username)
    
    if user and user['password'] == password:
        if not user['is_active']:
            return jsonify({'error': 'Account is disabled'}), 403
        
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['role'] = user['role']
        
        update_last_login(user['id'])
        add_log('LOGIN', f'User {username} logged in', user_id=user['id'], severity='info')
        
        return jsonify({
            'success': True,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'role': user['role'],
                'email': user['email']
            }
        })
    
    add_log('LOGIN_FAILED', f'Failed login attempt for {username}', severity='warning')
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/api/auth/logout', methods=['POST'])
@login_required
def logout():
    """تسجيل الخروج"""
    user_id = session.get('user_id')
    username = session.get('username')
    add_log('LOGOUT', f'User {username} logged out', user_id=user_id, severity='info')
    session.clear()
    return jsonify({'success': True, 'message': 'Logged out successfully'})

@app.route('/api/auth/me', methods=['GET'])
@login_required
def get_current_user():
    """الحصول على المستخدم الحالي"""
    user = get_user_by_id(session['user_id'])
    if user:
        return jsonify({
            'id': user['id'],
            'username': user['username'],
            'role': user['role'],
            'email': user['email'],
            'phone': user['phone'],
            'last_login': user['last_login']
        })
    return jsonify({'error': 'User not found'}), 404

# ==================== User Management Routes ====================

@app.route('/api/users', methods=['GET'])
@admin_required
def get_users():
    """الحصول على جميع المستخدمين"""
    users = get_all_users()
    return jsonify({'users': users})

@app.route('/api/users', methods=['POST'])
@admin_required
def create_user():
    """إنشاء مستخدم جديد"""
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    role = data.get('role', 'viewer')
    email = data.get('email')
    phone = data.get('phone')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    user_id = add_user(username, password, role, email, phone)
    
    if user_id:
        add_log('USER_CREATED', f'User {username} created with role {role}', 
                user_id=session['user_id'], severity='info')
        return jsonify({'success': True, 'user_id': user_id})
    
    return jsonify({'error': 'Username already exists'}), 409

# ==================== Device Management Routes ====================

@app.route('/api/devices', methods=['GET'])
@login_required
def list_devices():
    """الحصول على جميع الأجهزة"""
    devices = get_all_devices()
    return jsonify({'devices': devices})

@app.route('/api/devices', methods=['POST'])
@engineer_required
def create_device():
    """إضافة جهاز جديد"""
    data = request.get_json()
    
    device_id = add_device(
        ip_address=data.get('ip_address'),
        hostname=data.get('hostname'),
        device_type=data.get('device_type'),
        vendor=data.get('vendor'),
        os_version=data.get('os_version'),
        username=data.get('username'),
        password=data.get('password'),
        enable_password=data.get('enable_password'),
        location=data.get('location'),
        created_by=session['user_id']
    )
    
    if device_id:
        add_log('DEVICE_ADDED', f"Device {data.get('hostname')} ({data.get('ip_address')}) added",
                user_id=session['user_id'], severity='info')
        return jsonify({'success': True, 'device_id': device_id})
    
    return jsonify({'error': 'Device with this IP already exists'}), 409

@app.route('/api/devices/<int:device_id>', methods=['GET'])
@login_required
def get_device(device_id):
    """الحصول على جهاز محدد"""
    device = get_device_by_id(device_id)
    if device:
        return jsonify({'device': device})
    return jsonify({'error': 'Device not found'}), 404

@app.route('/api/devices/<int:device_id>', methods=['DELETE'])
@admin_required
def remove_device(device_id):
    """حذف جهاز"""
    device = get_device_by_id(device_id)
    if device:
        delete_device(device_id)
        add_log('DEVICE_DELETED', f"Device {device['hostname']} deleted",
                user_id=session['user_id'], severity='warning')
        return jsonify({'success': True})
    return jsonify({'error': 'Device not found'}), 404

@app.route('/api/devices/<int:device_id>/ping', methods=['POST'])
@engineer_required
def ping_device_route(device_id):
    """Ping جهاز"""
    device = get_device_by_id(device_id)
    if not device:
        return jsonify({'error': 'Device not found'}), 404
    
    ip = device['ip_address']
    try:
        result = subprocess.run(['ping', '-n', '4', ip], 
                              capture_output=True, text=True, timeout=30)
        success = result.returncode == 0
        
        if success:
            update_device_status(device_id, 'up')
            add_log('PING_SUCCESS', f'Device {ip} is reachable',
                    user_id=session['user_id'], device_id=device_id, severity='info')
        else:
            update_device_status(device_id, 'down')
            add_log('PING_FAILED', f'Device {ip} is unreachable',
                    user_id=session['user_id'], device_id=device_id, severity='warning')
        
        return jsonify({
            'success': success,
            'ip': ip,
            'output': result.stdout
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ==================== Monitoring Routes ====================

@app.route('/api/monitoring/dashboard', methods=['GET'])
@login_required
def get_dashboard_data():
    """الحصول على بيانات Dashboard"""
    devices = get_all_devices()
    alerts = get_alerts(unread_only=True)
    logs = get_all_logs(limit=10)
    
    # إحصائيات
    total_devices = len(devices)
    online_devices = sum(1 for d in devices if d['status'] == 'up')
    offline_devices = sum(1 for d in devices if d['status'] == 'down')
    unknown_devices = total_devices - online_devices - offline_devices
    
    # مشاكل الأمان
    security_issues = get_security_issues(status='open')
    
    return jsonify({
        'stats': {
            'total_devices': total_devices,
            'online_devices': online_devices,
            'offline_devices': offline_devices,
            'unknown_devices': unknown_devices,
            'unread_alerts': len(alerts),
            'open_security_issues': len(security_issues)
        },
        'devices': devices[:5],  # آخر 5 أجهزة
        'alerts': alerts[:5],    # آخر 5 تنبيهات
        'logs': logs,            # آخر 10 سجلات
        'security_issues': security_issues[:5]
    })

@app.route('/api/monitoring/performance', methods=['GET'])
@login_required
def get_performance():
    """الحصول على بيانات الأداء"""
    device_id = request.args.get('device_id', type=int)
    limit = request.args.get('limit', 100, type=int)
    
    data = get_performance_data(device_id=device_id, limit=limit)
    return jsonify({'performance_data': data})

@app.route('/api/monitoring/logs', methods=['GET'])
@login_required
def get_logs():
    """الحصول على السجلات"""
    limit = request.args.get('limit', 100, type=int)
    severity = request.args.get('severity')
    
    if severity:
        from database.db_manager import get_logs_by_severity
        logs = get_logs_by_severity(severity)
    else:
        logs = get_all_logs(limit=limit)
    
    return jsonify({'logs': logs})

# ==================== Security Routes ====================

@app.route('/api/security/issues', methods=['GET'])
@login_required
def list_security_issues():
    """الحصول على مشاكل الأمان"""
    status = request.args.get('status', 'open')
    issues = get_security_issues(status=status)
    return jsonify({'issues': issues})

@app.route('/api/security/issues', methods=['POST'])
@engineer_required
def create_security_issue():
    """إضافة مشكلة أمان"""
    data = request.get_json()
    
    add_security_issue(
        device_id=data.get('device_id'),
        issue_type=data.get('issue_type'),
        severity=data.get('severity'),
        description=data.get('description'),
        source_ip=data.get('source_ip'),
        target_ip=data.get('target_ip'),
        attack_type=data.get('attack_type'),
        solution=data.get('solution')
    )
    
    # إضافة تنبيه
    add_alert(
        alert_type='security',
        severity=data.get('severity'),
        title=f"Security Issue: {data.get('issue_type')}",
        message=data.get('description'),
        device_id=data.get('device_id')
    )
    
    add_log('SECURITY_ISSUE', f"Security issue detected: {data.get('issue_type')}",
            user_id=session['user_id'], device_id=data.get('device_id'),
            severity=data.get('severity'))
    
    return jsonify({'success': True})

# ==================== Backup Routes ====================

@app.route('/api/backups', methods=['GET'])
@login_required
def list_backups():
    """الحصول على النسخ الاحتياطية"""
    device_id = request.args.get('device_id', type=int)
    backups = get_backups(device_id=device_id)
    return jsonify({'backups': backups})

@app.route('/api/backups', methods=['POST'])
@engineer_required
def create_backup():
    """إنشاء نسخة احتياطية"""
    data = request.get_json()
    
    device_id = data.get('device_id')
    device = get_device_by_id(device_id)
    
    if not device:
        return jsonify({'error': 'Device not found'}), 404
    
    # محاكاة إنشاء نسخة احتياطية
    backup_file = f"backup_{device['hostname']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.cfg"
    backup_path = os.path.join('backups', backup_file)
    
    # إنشاء المجلد إذا لم يكن موجوداً
    os.makedirs('backups', exist_ok=True)
    
    # كتابة محتوى وهمي للنسخة الاحتياطية
    config_content = f"! Backup for {device['hostname']}\n! Created: {datetime.now()}\n! Device: {device['ip_address']}\n"
    
    with open(backup_path, 'w') as f:
        f.write(config_content)
    
    add_backup(
        device_id=device_id,
        backup_type=data.get('backup_type', 'manual'),
        file_path=backup_path,
        file_size=len(config_content),
        config_content=config_content,
        performed_by=session['user_id'],
        notes=data.get('notes')
    )
    
    add_log('BACKUP_CREATED', f"Backup created for {device['hostname']}",
            user_id=session['user_id'], device_id=device_id, severity='info')
    
    return jsonify({'success': True, 'file': backup_file})

# ==================== AI Routes ====================

@app.route('/api/ai/packet-analysis', methods=['GET'])
@login_required
def get_packet_analysis():
    """الحصول على تحليل Packets"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT p.*, d.hostname, d.ip_address
        FROM packet_analysis p
        JOIN devices d ON p.device_id = d.id
        ORDER BY p.analyzed_at DESC
        LIMIT 50
    ''')
    analyses = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({'analyses': analyses})

@app.route('/api/ai/packet-analysis', methods=['POST'])
@engineer_required
def create_packet_analysis():
    """إنشاء تحليل Packet جديد"""
    data = request.get_json()
    
    # محاكاة تحليل AI
    packet_data = data.get('packet_data', '')
    
    # تحليل بسيط للمخاطر
    risk_level = 'low'
    threat_type = 'Normal Traffic'
    analysis_result = 'No threats detected'
    recommended_action = 'Continue monitoring'
    
    if 'arp' in packet_data.lower() and ('spoof' in packet_data.lower() or 'fake' in packet_data.lower()):
        risk_level = 'high'
        threat_type = 'ARP Spoofing'
        analysis_result = 'ARP spoofing attack detected - MAC address mismatch'
        recommended_action = 'Enable Dynamic ARP Inspection immediately'
    elif 'syn' in packet_data.lower() and 'flood' in packet_data.lower():
        risk_level = 'high'
        threat_type = 'SYN Flood'
        analysis_result = 'Potential DoS attack - High volume of SYN packets'
        recommended_action = 'Enable SYN cookies and rate limiting'
    elif 'icmp' in packet_data.lower() and 'flood' in packet_data.lower():
        risk_level = 'medium'
        threat_type = 'ICMP Flood'
        analysis_result = 'ICMP flood detected'
        recommended_action = 'Configure ICMP rate limiting'
    
    add_packet_analysis(
        device_id=data.get('device_id'),
        packet_data=packet_data,
        risk_level=risk_level,
        threat_type=threat_type,
        source_ip=data.get('source_ip'),
        destination_ip=data.get('destination_ip'),
        protocol=data.get('protocol'),
        analysis_result=analysis_result,
        recommended_action=recommended_action
    )
    
    if risk_level in ['high', 'critical']:
        add_alert(
            alert_type='ai_detection',
            severity=risk_level,
            title=f'AI Alert: {threat_type}',
            message=analysis_result,
            device_id=data.get('device_id')
        )
    
    return jsonify({
        'success': True,
        'risk_level': risk_level,
        'threat_type': threat_type,
        'analysis_result': analysis_result,
        'recommended_action': recommended_action
    })

@app.route('/api/ai/traffic-analysis', methods=['GET'])
@login_required
def get_traffic_analysis():
    """الحصول على تحليل Traffic"""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT t.*, d.hostname, d.ip_address
        FROM traffic_analysis t
        JOIN devices d ON t.device_id = d.id
        ORDER BY t.analyzed_at DESC
        LIMIT 50
    ''')
    analyses = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({'analyses': analyses})

@app.route('/api/ai/traffic-analysis', methods=['POST'])
@engineer_required
def create_traffic_analysis():
    """إنشاء تحليل Traffic جديد"""
    data = request.get_json()
    
    # محاكاة تحليل AI للـ Traffic
    traffic_volume = data.get('traffic_volume', 0)
    bandwidth_usage = data.get('bandwidth_usage', 0)
    
    # تحليل بسيط
    risk_level = 'low'
    abnormal_patterns = 'None detected'
    source_analysis = 'Normal traffic patterns'
    recommendations = 'Continue monitoring'
    
    if bandwidth_usage > 90:
        risk_level = 'high'
        abnormal_patterns = 'Bandwidth saturation detected'
        source_analysis = 'Possible DDoS attack or bandwidth abuse'
        recommendations = 'Implement traffic shaping and investigate source'
    elif bandwidth_usage > 70:
        risk_level = 'medium'
        abnormal_patterns = 'High bandwidth usage'
        source_analysis = 'Unusual traffic volume detected'
        recommendations = 'Monitor closely and identify top talkers'
    elif traffic_volume > 10000:
        risk_level = 'medium'
        abnormal_patterns = 'High packet count'
        source_analysis = 'Possible scanning activity'
        recommendations = 'Check for port scanning or reconnaissance'
    
    add_traffic_analysis(
        device_id=data.get('device_id'),
        traffic_volume=traffic_volume,
        bandwidth_usage=bandwidth_usage,
        abnormal_patterns=abnormal_patterns,
        risk_level=risk_level,
        source_analysis=source_analysis,
        recommendations=recommendations
    )
    
    return jsonify({
        'success': True,
        'risk_level': risk_level,
        'abnormal_patterns': abnormal_patterns,
        'source_analysis': source_analysis,
        'recommendations': recommendations
    })

@app.route('/api/ai/knowledge-base', methods=['GET'])
@login_required
def get_knowledge_base():
    """الحصول على قاعدة المعرفة"""
    problem_type = request.args.get('problem_type')
    device_type = request.args.get('device_type')
    
    solutions = get_knowledge_base_solutions(problem_type, device_type)
    return jsonify({'solutions': solutions})

@app.route('/api/ai/chatbot', methods=['POST'])
@login_required
def ai_chatbot():
    """Chatbot للمساعدة في حل المشاكل"""
    data = request.get_json()
    problem = data.get('problem', '').lower()
    device_type = data.get('device_type', '')
    
    # قاعدة معرفة بسيطة للـ Chatbot
    responses = {
        'interface down': {
            'solutions': [
                'Check physical cable connections and LED indicators',
                'Use "show interface" command to check interface status',
                'Try "shutdown" then "no shutdown" to restart interface'
            ],
            'severity': 'medium'
        },
        'high cpu': {
            'solutions': [
                'Use "show processes cpu" to identify high CPU processes',
                'Check for routing loops or broadcast storms',
                'Consider upgrading hardware if consistently high'
            ],
            'severity': 'high'
        },
        'slow network': {
            'solutions': [
                'Check interface counters for errors or drops',
                'Verify duplex and speed settings match on both ends',
                'Monitor bandwidth utilization during peak hours'
            ],
            'severity': 'medium'
        },
        'arp spoofing': {
            'solutions': [
                'Enable Dynamic ARP Inspection (DAI) on switches',
                'Configure static ARP entries for critical devices',
                'Enable ARP inspection trust on legitimate ports'
            ],
            'severity': 'high'
        },
        'dos attack': {
            'solutions': [
                'Enable rate limiting on interfaces',
                'Configure ACLs to block attack source',
                'Enable TCP intercept and connection limiting'
            ],
            'severity': 'critical'
        },
        'vlan issue': {
            'solutions': [
                'Verify VLAN configuration with "show vlan brief"',
                'Check trunk ports allow required VLANs',
                'Verify access ports are assigned to correct VLAN'
            ],
            'severity': 'medium'
        },
        'routing problem': {
            'solutions': [
                'Check routing table with "show ip route"',
                'Verify routing protocol neighbors are established',
                'Check for route flapping or blackholes'
            ],
            'severity': 'high'
        }
    }
    
    # البحث عن أفضل تطابق
    best_match = None
    for key in responses:
        if key in problem:
            best_match = responses[key]
            break
    
    if best_match:
        return jsonify({
            'success': True,
            'problem_detected': True,
            'severity': best_match['severity'],
            'solutions': best_match['solutions']
        })
    
    # رد افتراضي
    return jsonify({
        'success': True,
        'problem_detected': False,
        'message': 'I could not identify a specific problem. Please provide more details about:',
        'suggestions': [
            'Device type (Router/Switch/Server)',
            'Specific error messages',
            'When the problem started',
            'Any recent configuration changes'
        ]
    })

# ==================== Alert Routes ====================

@app.route('/api/alerts', methods=['GET'])
@login_required
def list_alerts():
    """الحصول على التنبيهات"""
    unread_only = request.args.get('unread_only', 'false').lower() == 'true'
    alerts = get_alerts(unread_only=unread_only)
    return jsonify({'alerts': alerts})

@app.route('/api/alerts/<int:alert_id>/read', methods=['POST'])
@login_required
def mark_alert_as_read(alert_id):
    """تحديد التنبيه كمقروء"""
    mark_alert_read(alert_id)
    return jsonify({'success': True})

# ==================== Report Routes ====================

@app.route('/api/reports/summary', methods=['GET'])
@login_required
def get_summary_report():
    """الحصول على تقرير ملخص"""
    devices = get_all_devices()
    logs = get_all_logs(limit=1000)
    security_issues = get_security_issues(status='open')
    performance_data = get_performance_data(limit=100)
    
    # إحصائيات
    device_stats = {
        'total': len(devices),
        'online': sum(1 for d in devices if d['status'] == 'up'),
        'offline': sum(1 for d in devices if d['status'] == 'down'),
        'by_type': {}
    }
    
    for d in devices:
        device_type = d.get('device_type', 'Unknown')
        device_stats['by_type'][device_type] = device_stats['by_type'].get(device_type, 0) + 1
    
    # إحصائيات اللوجز
    log_stats = {
        'total': len(logs),
        'by_severity': {}
    }
    
    for log in logs:
        severity = log.get('severity', 'info')
        log_stats['by_severity'][severity] = log_stats['by_severity'].get(severity, 0) + 1
    
    return jsonify({
        'generated_at': datetime.now().isoformat(),
        'device_stats': device_stats,
        'log_stats': log_stats,
        'security_issues_count': len(security_issues),
        'performance_samples': len(performance_data)
    })

# ==================== Static Files ====================

@app.route('/api/reports/export', methods=['GET'])
@login_required
def export_report():
    """تصدير تقرير"""
    report_type = request.args.get('type', 'summary')
    format_type = request.args.get('format', 'json')
    
    if format_type == 'json':
        # تصدير JSON
        data = {
            'generated_at': datetime.now().isoformat(),
            'devices': get_all_devices(),
            'logs': get_all_logs(limit=1000),
            'security_issues': get_security_issues(status='open'),
            'backups': get_backups()
        }
        
        report_file = f'report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
        report_path = os.path.join('reports', report_file)
        os.makedirs('reports', exist_ok=True)
        
        with open(report_path, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        
        return send_file(report_path, as_attachment=True)
    
    return jsonify({'error': 'Unsupported format'}), 400

# ==================== Error Handlers ====================

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

# ==================== Main ====================

if __name__ == '__main__':
    # تهيئة قاعدة البيانات
    init_database()
    seed_initial_data()
    
    # إنشاء المجلدات اللازمة
    os.makedirs('backups', exist_ok=True)
    os.makedirs('reports', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    print("=" * 60)
    print("🚀 SIM-NET Backend Server")
    print("=" * 60)
    print("📡 Server running on http://localhost:5000")
    print("📊 API Documentation available at http://localhost:5000")
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5000, debug=True)
