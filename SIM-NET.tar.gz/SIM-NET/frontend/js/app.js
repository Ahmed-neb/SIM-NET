/**
 * SIM-NET Frontend Application
 * =============================
 * تطبيق الواجهة الأمامية لنظام إدارة الشبكات
 */

// API Base URL
const API_BASE_URL = 'http://localhost:5000/api';

// Global State
let currentUser = null;
let devices = [];
let charts = {};
let map = null;
let deviceMarkers = [];

// ==================== Initialization ====================

document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

function initApp() {
    // Check if user is logged in
    const savedUser = localStorage.getItem('simnet_user');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        showMainApp();
    } else {
        showLoginPage();
    }
    
    // Setup event listeners
    setupEventListeners();
}

function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const page = item.dataset.page;
            navigateToPage(page);
        });
    });
    
    // Modals
    setupModals();
    
    // Page-specific buttons
    setupPageButtons();
}

function setupModals() {
    // Close modal buttons
    document.querySelectorAll('.modal-close, .modal-cancel').forEach(btn => {
        btn.addEventListener('click', closeAllModals);
    });
    
    // Add Device Modal
    const addDeviceBtn = document.getElementById('add-device-btn');
    if (addDeviceBtn) {
        addDeviceBtn.addEventListener('click', () => {
            openModal('add-device-modal');
        });
    }
    
    const addDeviceForm = document.getElementById('add-device-form');
    if (addDeviceForm) {
        addDeviceForm.addEventListener('submit', handleAddDevice);
    }
    
    // Add User Modal
    const addUserBtn = document.getElementById('add-user-btn');
    if (addUserBtn) {
        addUserBtn.addEventListener('click', () => {
            openModal('add-user-modal');
        });
    }
    
    const addUserForm = document.getElementById('add-user-form');
    if (addUserForm) {
        addUserForm.addEventListener('submit', handleAddUser);
    }
}

function setupPageButtons() {
    // Dashboard buttons
    const refreshDevicesBtn = document.getElementById('refresh-devices-btn');
    if (refreshDevicesBtn) {
        refreshDevicesBtn.addEventListener('click', loadDevices);
    }
    
    // Monitoring buttons
    const startMonitoringBtn = document.getElementById('start-monitoring-btn');
    if (startMonitoringBtn) {
        startMonitoringBtn.addEventListener('click', startMonitoring);
    }
    
    const pingAllBtn = document.getElementById('ping-all-btn');
    if (pingAllBtn) {
        pingAllBtn.addEventListener('click', pingAllDevices);
    }
    
    // Performance buttons
    const refreshPerformanceBtn = document.getElementById('refresh-performance-btn');
    if (refreshPerformanceBtn) {
        refreshPerformanceBtn.addEventListener('click', loadPerformanceData);
    }
    
    const performanceDeviceSelect = document.getElementById('performance-device-select');
    if (performanceDeviceSelect) {
        performanceDeviceSelect.addEventListener('change', loadPerformanceData);
    }
    
    // Logs buttons
    const refreshLogsBtn = document.getElementById('refresh-logs-btn');
    if (refreshLogsBtn) {
        refreshLogsBtn.addEventListener('click', loadLogs);
    }
    
    const logFilter = document.getElementById('log-filter');
    if (logFilter) {
        logFilter.addEventListener('change', loadLogs);
    }
    
    // AI Chatbot
    const sendMessageBtn = document.getElementById('send-message-btn');
    if (sendMessageBtn) {
        sendMessageBtn.addEventListener('click', sendChatMessage);
    }
    
    const chatInput = document.getElementById('chat-input');
    if (chatInput) {
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendChatMessage();
            }
        });
    }
    
    // Reports
    const generateReportBtn = document.getElementById('generate-report-btn');
    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', generateReport);
    }
    
    const exportJsonBtn = document.getElementById('export-json-btn');
    if (exportJsonBtn) {
        exportJsonBtn.addEventListener('click', exportReportJson);
    }
}

// ==================== Authentication ====================

async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        // For demo purposes, using local authentication
        // In production, this should call the backend API
        const users = [
            { username: 'admin', password: 'admin123', role: 'admin', email: 'admin@simnet.local' },
            { username: 'engineer', password: 'engineer123', role: 'engineer', email: 'engineer@simnet.local' },
            { username: 'viewer', password: 'viewer123', role: 'viewer', email: 'viewer@simnet.local' }
        ];
        
        const user = users.find(u => u.username === username && u.password === password);
        
        if (user) {
            currentUser = {
                username: user.username,
                role: user.role,
                email: user.email
            };
            
            localStorage.setItem('simnet_user', JSON.stringify(currentUser));
            showToast('success', 'تم تسجيل الدخول بنجاح!');
            showMainApp();
        } else {
            showToast('error', 'اسم المستخدم أو كلمة المرور غير صحيحة');
        }
    } catch (error) {
        showToast('error', 'حدث خطأ أثناء تسجيل الدخول');
        console.error('Login error:', error);
    }
}

function handleLogout() {
    currentUser = null;
    localStorage.removeItem('simnet_user');
    showToast('info', 'تم تسجيل الخروج');
    showLoginPage();
}

// ==================== Navigation ====================

function showLoginPage() {
    document.getElementById('login-page').classList.remove('hidden');
    document.getElementById('main-app').classList.add('hidden');
}

function showMainApp() {
    document.getElementById('login-page').classList.add('hidden');
    document.getElementById('main-app').classList.remove('hidden');
    
    // Update UI
    document.getElementById('current-user').textContent = currentUser.username;
    
    // Show/hide admin elements
    document.querySelectorAll('.admin-only').forEach(el => {
        el.style.display = currentUser.role === 'admin' ? 'flex' : 'none';
    });
    
    // Show/hide engineer elements
    document.querySelectorAll('.engineer-only').forEach(el => {
        el.style.display = ['admin', 'engineer'].includes(currentUser.role) ? 'inline-flex' : 'none';
    });
    
    // Load initial data
    loadDashboardData();
    loadDevices();
    loadAlerts();
    loadLogs();
}

function navigateToPage(page) {
    // Update active nav item
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === page) {
            item.classList.add('active');
        }
    });
    
    // Show selected page
    document.querySelectorAll('.page').forEach(p => {
        p.classList.remove('active');
    });
    
    const selectedPage = document.getElementById(`${page}-page`);
    if (selectedPage) {
        selectedPage.classList.add('active');
    }
    
    // Update page title
    const pageTitles = {
        'dashboard': 'لوحة التحكم',
        'devices': 'إدارة الأجهزة',
        'monitoring': 'المراقبة',
        'security': 'الأمان',
        'performance': 'الأداء',
        'ai-analysis': 'تحليل AI',
        'reports': 'التقارير',
        'logs': 'السجلات',
        'users': 'المستخدمين'
    };
    
    document.getElementById('page-title').textContent = pageTitles[page] || page;
    
    // Load page-specific data
    if (page === 'devices') {
        loadDevices();
    } else if (page === 'performance') {
        loadPerformanceData();
        populateDeviceSelect();
    } else if (page === 'security') {
        loadSecurityData();
    } else if (page === 'ai-analysis') {
        loadAIAnalysisData();
    } else if (page === 'reports') {
        loadReportData();
    } else if (page === 'users') {
        loadUsers();
    } else if (page === 'dashboard') {
        loadDashboardData();
    }
}

// ==================== Dashboard ====================

async function loadDashboardData() {
    try {
        // Simulate API call - in production, fetch from backend
        const mockData = {
            stats: {
                total_devices: 12,
                online_devices: 10,
                offline_devices: 2,
                unread_alerts: 3,
                open_security_issues: 1
            },
            devices: [
                { id: 1, ip_address: '192.168.1.1', hostname: 'Router-Main', device_type: 'Router', vendor: 'Cisco', status: 'up', last_seen: '2024-01-15 10:30:00' },
                { id: 2, ip_address: '192.168.1.2', hostname: 'Switch-Core', device_type: 'Switch', vendor: 'Cisco', status: 'up', last_seen: '2024-01-15 10:30:00' },
                { id: 3, ip_address: '192.168.1.10', hostname: 'Server-DC', device_type: 'Server', vendor: 'HP', status: 'down', last_seen: '2024-01-15 09:00:00' }
            ],
            alerts: [
                { id: 1, severity: 'high', title: 'Device Down', message: 'Server-DC is unreachable', created_at: '2024-01-15 09:00:00' },
                { id: 2, severity: 'medium', title: 'High CPU Usage', message: 'Router-Main CPU > 80%', created_at: '2024-01-15 08:30:00' }
            ],
            logs: [
                { event_type: 'LOGIN', description: 'User admin logged in', username: 'admin', created_at: '2024-01-15 10:00:00', severity: 'info' },
                { event_type: 'DEVICE_DOWN', description: 'Server-DC is down', hostname: 'Server-DC', created_at: '2024-01-15 09:00:00', severity: 'error' }
            ]
        };
        
        // Update stats
        document.getElementById('total-devices').textContent = mockData.stats.total_devices;
        document.getElementById('online-devices').textContent = mockData.stats.online_devices;
        document.getElementById('offline-devices').textContent = mockData.stats.offline_devices;
        document.getElementById('security-alerts').textContent = mockData.stats.unread_alerts;
        document.getElementById('notification-count').textContent = mockData.stats.unread_alerts;
        
        // Update alerts
        updateAlertsList(mockData.alerts);
        
        // Update logs
        updateRecentLogs(mockData.logs);
        
        // Initialize charts
        initDeviceStatusChart(mockData.stats);
        
        // Initialize map
        initDeviceMap(mockData.devices);
        
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

function updateAlertsList(alerts) {
    const container = document.getElementById('recent-alerts');
    if (!alerts || alerts.length === 0) {
        container.innerHTML = '<p class="empty-state">لا توجد تنبيهات جديدة</p>';
        return;
    }
    
    container.innerHTML = alerts.map(alert => `
        <div class="list-item">
            <div class="list-item-icon ${alert.severity === 'high' ? 'red' : alert.severity === 'medium' ? 'orange' : 'green'}">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="list-item-content">
                <div class="list-item-title">${alert.title}</div>
                <div class="list-item-subtitle">${alert.message}</div>
            </div>
            <div class="list-item-time">${formatTime(alert.created_at)}</div>
        </div>
    `).join('');
}

function updateRecentLogs(logs) {
    const container = document.getElementById('recent-logs');
    if (!logs || logs.length === 0) {
        container.innerHTML = '<p class="empty-state">لا توجد أنشطة حديثة</p>';
        return;
    }
    
    container.innerHTML = logs.map(log => `
        <div class="list-item">
            <div class="list-item-icon ${log.severity === 'error' ? 'red' : log.severity === 'warning' ? 'orange' : 'green'}">
                <i class="fas fa-${log.severity === 'error' ? 'times' : log.severity === 'warning' ? 'exclamation' : 'info'}"></i>
            </div>
            <div class="list-item-content">
                <div class="list-item-title">${log.event_type}</div>
                <div class="list-item-subtitle">${log.description}</div>
            </div>
            <div class="list-item-time">${formatTime(log.created_at)}</div>
        </div>
    `).join('');
}

// ==================== Charts ====================

function initDeviceStatusChart(stats) {
    const ctx = document.getElementById('device-status-chart');
    if (!ctx) return;
    
    if (charts.deviceStatus) {
        charts.deviceStatus.destroy();
    }
    
    charts.deviceStatus = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Online', 'Offline', 'Unknown'],
            datasets: [{
                data: [stats.online_devices, stats.offline_devices, stats.unknown_devices || 0],
                backgroundColor: ['#10b981', '#ef4444', '#64748b'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#94a3b8',
                        padding: 15
                    }
                }
            },
            cutout: '70%'
        }
    });
}

function initCpuChart(data) {
    const ctx = document.getElementById('cpu-chart');
    if (!ctx) return;
    
    if (charts.cpu) {
        charts.cpu.destroy();
    }
    
    charts.cpu = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'CPU Usage %',
                data: data.values,
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: '#334155'
                    },
                    ticks: {
                        color: '#94a3b8'
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#94a3b8'
                    }
                }
            }
        }
    });
}

function initMemoryChart(data) {
    const ctx = document.getElementById('memory-chart');
    if (!ctx) return;
    
    if (charts.memory) {
        charts.memory.destroy();
    }
    
    charts.memory = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Memory Usage %',
                data: data.values,
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: '#334155'
                    },
                    ticks: {
                        color: '#94a3b8'
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#94a3b8'
                    }
                }
            }
        }
    });
}

// ==================== Map ====================

function initDeviceMap(devices) {
    const mapContainer = document.getElementById('device-map');
    if (!mapContainer) return;
    
    if (map) {
        map.remove();
    }
    
    map = L.map('device-map').setView([24.7136, 46.6753], 5);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    // Clear existing markers
    deviceMarkers.forEach(marker => map.removeLayer(marker));
    deviceMarkers = [];
    
    // Add device markers (simulated positions)
    devices.forEach((device, index) => {
        // Simulate positions around Saudi Arabia
        const lat = 24.7136 + (Math.random() - 0.5) * 4;
        const lng = 46.6753 + (Math.random() - 0.5) * 4;
        
        const iconColor = device.status === 'up' ? 'green' : 'red';
        const icon = L.divIcon({
            className: 'custom-marker',
            html: `<i class="fas fa-server" style="color: ${iconColor}; font-size: 20px;"></i>`,
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });
        
        const marker = L.marker([lat, lng], { icon })
            .addTo(map)
            .bindPopup(`
                <strong>${device.hostname}</strong><br>
                IP: ${device.ip_address}<br>
                Type: ${device.device_type}<br>
                Status: ${device.status}
            `);
        
        deviceMarkers.push(marker);
    });
}

// ==================== Devices ====================

async function loadDevices() {
    try {
        // Simulate API call
        devices = [
            { id: 1, ip_address: '192.168.1.1', hostname: 'Router-Main', device_type: 'Router', vendor: 'Cisco', os_version: '15.7', status: 'up', last_seen: '2024-01-15 10:30:00' },
            { id: 2, ip_address: '192.168.1.2', hostname: 'Switch-Core', device_type: 'Switch', vendor: 'Cisco', os_version: '15.2', status: 'up', last_seen: '2024-01-15 10:30:00' },
            { id: 3, ip_address: '192.168.1.3', hostname: 'Switch-Access-1', device_type: 'Switch', vendor: 'Cisco', os_version: '15.2', status: 'up', last_seen: '2024-01-15 10:25:00' },
            { id: 4, ip_address: '192.168.1.10', hostname: 'Server-DC', device_type: 'Server', vendor: 'HP', os_version: 'Windows 2019', status: 'down', last_seen: '2024-01-15 09:00:00' },
            { id: 5, ip_address: '192.168.1.254', hostname: 'Firewall-Edge', device_type: 'Firewall', vendor: 'Cisco', os_version: 'ASA 9.12', status: 'up', last_seen: '2024-01-15 10:30:00' }
        ];
        
        updateDevicesTable(devices);
        
    } catch (error) {
        console.error('Error loading devices:', error);
        showToast('error', 'فشل تحميل الأجهزة');
    }
}

function updateDevicesTable(devices) {
    const tbody = document.querySelector('#devices-table tbody');
    if (!tbody) return;
    
    if (devices.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="text-center">لا توجد أجهزة</td></tr>';
        return;
    }
    
    tbody.innerHTML = devices.map(device => `
        <tr>
            <td>${device.ip_address}</td>
            <td>${device.hostname}</td>
            <td>${device.device_type}</td>
            <td>${device.vendor}</td>
            <td><span class="status-badge ${device.status}">${device.status === 'up' ? 'Online' : device.status === 'down' ? 'Offline' : 'Unknown'}</span></td>
            <td>${formatTime(device.last_seen)}</td>
            <td>
                <button class="btn btn-sm btn-secondary" onclick="pingDevice(${device.id})">
                    <i class="fas fa-network-wired"></i>
                </button>
                <button class="btn btn-sm btn-danger admin-only" onclick="deleteDevice(${device.id})" style="display: ${currentUser.role === 'admin' ? 'inline-flex' : 'none'}">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

async function handleAddDevice(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const deviceData = {
        ip_address: formData.get('ip_address'),
        hostname: formData.get('hostname'),
        device_type: formData.get('device_type'),
        vendor: formData.get('vendor'),
        username: formData.get('username'),
        password: formData.get('password'),
        location: formData.get('location')
    };
    
    try {
        // Simulate API call
        const newDevice = {
            id: devices.length + 1,
            ...deviceData,
            status: 'unknown',
            last_seen: null
        };
        
        devices.push(newDevice);
        updateDevicesTable(devices);
        closeAllModals();
        showToast('success', 'تم إضافة الجهاز بنجاح');
        e.target.reset();
        
    } catch (error) {
        console.error('Error adding device:', error);
        showToast('error', 'فشل إضافة الجهاز');
    }
}

function pingDevice(deviceId) {
    const device = devices.find(d => d.id === deviceId);
    if (!device) return;
    
    showToast('info', `جاري Ping لـ ${device.hostname}...`);
    
    // Simulate ping
    setTimeout(() => {
        const success = Math.random() > 0.3;
        if (success) {
            showToast('success', `${device.hostname} متاح (Ping ناجح)`);
        } else {
            showToast('error', `${device.hostname} غير متاح (Ping فاشل)`);
        }
    }, 1500);
}

function deleteDevice(deviceId) {
    if (!confirm('هل أنت متأكد من حذف هذا الجهاز؟')) return;
    
    devices = devices.filter(d => d.id !== deviceId);
    updateDevicesTable(devices);
    showToast('success', 'تم حذف الجهاز');
}

function pingAllDevices() {
    showToast('info', 'جاري Ping لجميع الأجهزة...');
    
    let online = 0;
    let offline = 0;
    
    devices.forEach((device, index) => {
        setTimeout(() => {
            const success = Math.random() > 0.3;
            device.status = success ? 'up' : 'down';
            device.last_seen = new Date().toISOString();
            
            if (success) online++;
            else offline++;
            
            if (index === devices.length - 1) {
                updateDevicesTable(devices);
                showToast('success', `Ping اكتمل: ${online} online, ${offline} offline`);
            }
        }, index * 500);
    });
}

// ==================== Monitoring ====================

function startMonitoring() {
    const statusDiv = document.getElementById('monitoring-status');
    statusDiv.innerHTML = `
        <div class="monitoring-status active">
            <i class="fas fa-heartbeat pulse"></i>
            <p>المراقبة نشطة...</p>
        </div>
    `;
    
    showToast('success', 'تم بدء المراقبة');
    
    // Simulate monitoring
    setInterval(() => {
        // Randomly update device status
        devices.forEach(device => {
            if (Math.random() > 0.95) {
                device.status = device.status === 'up' ? 'down' : 'up';
                device.last_seen = new Date().toISOString();
                
                if (device.status === 'down') {
                    showToast('warning', `تنبيه: ${device.hostname} غير متاح!`);
                }
            }
        });
        
        if (document.getElementById('devices-page').classList.contains('active')) {
            updateDevicesTable(devices);
        }
    }, 10000);
}

// ==================== Performance ====================

async function loadPerformanceData() {
    try {
        const deviceId = document.getElementById('performance-device-select')?.value;
        
        // Generate mock data
        const labels = [];
        const cpuData = [];
        const memoryData = [];
        
        for (let i = 10; i >= 0; i--) {
            labels.push(`${i}m ago`);
            cpuData.push(Math.floor(Math.random() * 60) + 20);
            memoryData.push(Math.floor(Math.random() * 50) + 30);
        }
        
        initCpuChart({ labels, values: cpuData });
        initMemoryChart({ labels, values: memoryData });
        
        // Update table
        const tbody = document.querySelector('#performance-table tbody');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td>${new Date().toLocaleString()}</td>
                    <td>Router-Main</td>
                    <td>${cpuData[cpuData.length - 1]}%</td>
                    <td>${memoryData[memoryData.length - 1]}%</td>
                    <td>${Math.floor(Math.random() * 40) + 20}%</td>
                    <td>${Math.floor(Math.random() * 20) + 5}ms</td>
                </tr>
            `;
        }
        
    } catch (error) {
        console.error('Error loading performance:', error);
    }
}

function populateDeviceSelect() {
    const select = document.getElementById('performance-device-select');
    if (!select) return;
    
    select.innerHTML = '<option value="">اختر جهازاً</option>' +
        devices.map(d => `<option value="${d.id}">${d.hostname}</option>`).join('');
}

// ==================== Security ====================

async function loadSecurityData() {
    try {
        const mockIssues = [
            { id: 1, issue_type: 'Port Scan', severity: 'medium', description: 'Port scanning detected from 192.168.1.100', source_ip: '192.168.1.100', detected_at: '2024-01-15 10:00:00' },
            { id: 2, issue_type: 'Weak Password', severity: 'high', description: 'Telnet using default credentials', source_ip: '192.168.1.1', detected_at: '2024-01-15 09:30:00' }
        ];
        
        document.getElementById('open-issues').textContent = mockIssues.length;
        document.getElementById('attacks-detected').textContent = 1;
        document.getElementById('resolved-issues').textContent = 5;
        
        const container = document.getElementById('security-issues-list');
        container.innerHTML = mockIssues.map(issue => `
            <div class="list-item">
                <div class="list-item-icon ${issue.severity === 'high' ? 'red' : 'orange'}">
                    <i class="fas fa-shield-virus"></i>
                </div>
                <div class="list-item-content">
                    <div class="list-item-title">${issue.issue_type}</div>
                    <div class="list-item-subtitle">${issue.description}</div>
                </div>
                <span class="severity-badge ${issue.severity}">${issue.severity}</span>
            </div>
        `).join('');
        
    } catch (error) {
        console.error('Error loading security data:', error);
    }
}

// ==================== AI Analysis ====================

async function loadAIAnalysisData() {
    try {
        // Load packet analysis
        const packetAnalyses = [
            { id: 1, risk_level: 'High', threat_type: 'ARP Spoofing', source_ip: '192.168.1.50', analyzed_at: '2024-01-15 10:30:00' },
            { id: 2, risk_level: 'Medium', threat_type: 'Port Scan', source_ip: '192.168.1.100', analyzed_at: '2024-01-15 10:15:00' }
        ];
        
        const container = document.getElementById('packet-analysis-list');
        container.innerHTML = packetAnalyses.map(analysis => `
            <div class="list-item">
                <div class="list-item-icon ${analysis.risk_level === 'High' ? 'red' : 'orange'}">
                    <i class="fas fa-bug"></i>
                </div>
                <div class="list-item-content">
                    <div class="list-item-title">${analysis.threat_type}</div>
                    <div class="list-item-subtitle">Source: ${analysis.source_ip}</div>
                </div>
                <span class="severity-badge ${analysis.risk_level.toLowerCase()}">${analysis.risk_level}</span>
            </div>
        `).join('');
        
    } catch (error) {
        console.error('Error loading AI analysis:', error);
    }
}

async function sendChatMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message
    addChatMessage('user', message);
    input.value = '';
    
    // Simulate AI response
    const responses = {
        'interface': {
            text: 'لقد اكتشفت مشكلة في Interface. إليك الحلول المقترحة:',
            solutions: [
                'تحقق من توصيلات الكابلات الفيزيائية',
                'استخدم "show ip interface brief" للتحقق من الحالة',
                'جرب "shutdown" ثم "no shutdown" لإعادة تشغيل Interface'
            ]
        },
        'cpu': {
            text: 'استخدام CPU مرتفع. إليك الحلول:',
            solutions: [
                'استخدم "show processes cpu" لتحديد العمليات',
                'تحقق من وجود Routing Loops',
                'تأكد من عدم وجود أوامر Debug نشطة'
            ]
        },
        'slow': {
            text: 'شبكة بطيئة. إليك الحلول:',
            solutions: [
                'تحقق من أخطاء Interface',
                'تأكد من تطابق Duplex و Speed',
                'راقب استخدام Bandwidth'
            ]
        }
    };
    
    let response = responses['interface'];
    for (const key in responses) {
        if (message.toLowerCase().includes(key)) {
            response = responses[key];
            break;
        }
    }
    
    setTimeout(() => {
        let html = `<p>${response.text}</p><ul>`;
        response.solutions.forEach(sol => {
            html += `<li>${sol}</li>`;
        });
        html += '</ul>';
        
        addChatMessage('bot', html);
    }, 1000);
}

function addChatMessage(sender, message) {
    const container = document.getElementById('chat-messages');
    const div = document.createElement('div');
    div.className = `message ${sender}`;
    div.innerHTML = message;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
}

// ==================== Reports ====================

async function loadReportData() {
    try {
        const reportData = {
            device_stats: {
                total: 12,
                online: 10,
                offline: 2,
                by_type: { Router: 3, Switch: 5, Server: 3, Firewall: 1 }
            },
            log_stats: {
                total: 156,
                by_severity: { info: 100, warning: 40, error: 15, critical: 1 }
            }
        };
        
        // Update device stats
        const deviceStatsDiv = document.getElementById('report-device-stats');
        deviceStatsDiv.innerHTML = `
            <div class="stat-box">
                <div class="stat-box-value">${reportData.device_stats.total}</div>
                <div class="stat-box-label">إجمالي الأجهزة</div>
            </div>
            <div class="stat-box">
                <div class="stat-box-value">${reportData.device_stats.online}</div>
                <div class="stat-box-label">Online</div>
            </div>
            <div class="stat-box">
                <div class="stat-box-value">${reportData.device_stats.offline}</div>
                <div class="stat-box-label">Offline</div>
            </div>
        `;
        
        // Update log stats
        const logStatsDiv = document.getElementById('report-log-stats');
        logStatsDiv.innerHTML = `
            <div class="stat-box">
                <div class="stat-box-value">${reportData.log_stats.total}</div>
                <div class="stat-box-label">إجمالي السجلات</div>
            </div>
            <div class="stat-box">
                <div class="stat-box-value">${reportData.log_stats.by_severity.error + reportData.log_stats.by_severity.critical}</div>
                <div class="stat-box-label">أخطاء</div>
            </div>
        `;
        
    } catch (error) {
        console.error('Error loading report:', error);
    }
}

function generateReport() {
    showToast('info', 'جاري توليد التقرير...');
    
    setTimeout(() => {
        showToast('success', 'تم توليد التقرير بنجاح!');
    }, 2000);
}

function exportReportJson() {
    const reportData = {
        generated_at: new Date().toISOString(),
        devices: devices,
        generated_by: currentUser.username
    };
    
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `simnet-report-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    showToast('success', 'تم تصدير التقرير');
}

// ==================== Logs ====================

async function loadLogs() {
    try {
        const filter = document.getElementById('log-filter')?.value;
        
        let logs = [
            { id: 1, event_type: 'LOGIN', description: 'User admin logged in', username: 'admin', hostname: null, created_at: '2024-01-15 10:00:00', severity: 'info' },
            { id: 2, event_type: 'DEVICE_ADDED', description: 'Device Router-Main added', username: 'admin', hostname: 'Router-Main', created_at: '2024-01-15 09:45:00', severity: 'info' },
            { id: 3, event_type: 'DEVICE_DOWN', description: 'Server-DC is unreachable', username: 'system', hostname: 'Server-DC', created_at: '2024-01-15 09:00:00', severity: 'error' },
            { id: 4, event_type: 'SECURITY_ALERT', description: 'Port scan detected', username: 'system', hostname: null, created_at: '2024-01-15 08:30:00', severity: 'warning' }
        ];
        
        if (filter) {
            logs = logs.filter(l => l.severity === filter);
        }
        
        const tbody = document.querySelector('#logs-table tbody');
        tbody.innerHTML = logs.map(log => `
            <tr>
                <td>${formatTime(log.created_at)}</td>
                <td>${log.event_type}</td>
                <td>${log.description}</td>
                <td>${log.username}</td>
                <td>${log.hostname || '-'}</td>
                <td><span class="severity-badge ${log.severity}">${log.severity}</span></td>
            </tr>
        `).join('');
        
    } catch (error) {
        console.error('Error loading logs:', error);
    }
}

// ==================== Users ====================

async function loadUsers() {
    try {
        const users = [
            { id: 1, username: 'admin', role: 'admin', email: 'admin@simnet.local', last_login: '2024-01-15 10:00:00', is_active: 1 },
            { id: 2, username: 'engineer', role: 'engineer', email: 'engineer@simnet.local', last_login: '2024-01-15 09:30:00', is_active: 1 },
            { id: 3, username: 'viewer', role: 'viewer', email: 'viewer@simnet.local', last_login: '2024-01-14 15:00:00', is_active: 1 }
        ];
        
        const tbody = document.querySelector('#users-table tbody');
        tbody.innerHTML = users.map(user => `
            <tr>
                <td>${user.id}</td>
                <td>${user.username}</td>
                <td>${user.role}</td>
                <td>${user.email}</td>
                <td>${formatTime(user.last_login)}</td>
                <td><span class="status-badge ${user.is_active ? 'up' : 'down'}">${user.is_active ? 'Active' : 'Inactive'}</span></td>
            </tr>
        `).join('');
        
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

async function handleAddUser(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const userData = {
        username: formData.get('username'),
        password: formData.get('password'),
        role: formData.get('role'),
        email: formData.get('email')
    };
    
    showToast('success', `تم إضافة المستخدم ${userData.username} بنجاح`);
    closeAllModals();
    e.target.reset();
    loadUsers();
}

// ==================== Alerts ====================

async function loadAlerts() {
    // Already loaded with dashboard
}

// ==================== Utilities ====================

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
    }
}

function closeAllModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('active');
    });
}

function showToast(type, message) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icons = {
        success: 'check-circle',
        error: 'times-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    
    toast.innerHTML = `
        <i class="fas fa-${icons[type]}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

function formatTime(timestamp) {
    if (!timestamp) return '-';
    
    const date = new Date(timestamp);
    const now = new Date();
    const diff = (now - date) / 1000; // seconds
    
    if (diff < 60) return 'منذ لحظات';
    if (diff < 3600) return `منذ ${Math.floor(diff / 60)} دقيقة`;
    if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} ساعة`;
    
    return date.toLocaleDateString('ar-SA');
}

// Close modals on outside click
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        closeAllModals();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeAllModals();
    }
});
